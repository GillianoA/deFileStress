
import java.util.*;

/**
 * 
 */
public class Assistant extends <> Traveler {

    /**
     * Default constructor
     */
    public Assistant() {
    }

}