
import java.util.*;

/**
 * 
 */
public class Librarian {

    /**
     * Default constructor
     */
    public Librarian() {
    }

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private Int empID;

    /**
     * @param cardNumber
     */
    public void scanCard(Int cardNumber) {
        // TODO implement here
    }

    /**
     * 
     */
    public void attemptBorrow() {
        // TODO implement here
    }

    /**
     * @param book
     */
    public void giveBook(String book) {
        // TODO implement here
    }

    /**
     * 
     */
    public void informOfFees() {
        // TODO implement here
    }

}