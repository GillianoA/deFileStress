
import java.util.*;

/**
 * 
 */
public class Burrower {

    /**
     * Default constructor
     */
    public Burrower() {
    }

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private Int cardNumber;

    /**
     * @param cardNumber
     */
    public void giveCard(Int cardNumber) {
        // TODO implement here
    }

    /**
     * @param book
     */
    public void requestBook(String book) {
        // TODO implement here
    }

}