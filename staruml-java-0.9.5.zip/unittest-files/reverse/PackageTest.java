package com.mycompany.packagetest;

public class __Temp {
}
