package com.mycompany.packagetest;

public class PublicClassTest {
}

protected class ProtectedClassTest {
}

private class PrivateClassTest {
}

class PackageClassTest {
}
