package com.mycompany.packagetest;

public interface InterfaceTest {
}
