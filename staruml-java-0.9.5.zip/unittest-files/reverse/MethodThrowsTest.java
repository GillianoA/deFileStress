package com.mycompany.packagetest;

public class MethodThrowsTest {

    void throwsTestMethod() throws java.lang.Exception {}

}
