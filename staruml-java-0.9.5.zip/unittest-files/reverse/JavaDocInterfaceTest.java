package com.mycompany.packagetest;

/**
 * JavaDoc for Interface
 */
public interface JavaDocInterfaceTest {

    /**
     * JavaDoc for Interface Field
     */
    static final int javaDocInterfaceField = 100;
    
    /**
     * JavaDoc for Interface Operation
     */
    void javaDocInterfaceOperation();
    
}
