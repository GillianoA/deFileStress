package com.mycompany.packagetest;

public final class InterfaceExtendsTest extends InterfaceTest {
}
