package com.mycompany.packagetest;

public class MethodGenericTest {
    
    public <T extends Product> void genericMethod(ArrayList<T> genericMethodListParam) {}
        
}
