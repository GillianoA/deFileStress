package com.mycompany.packagetest;

public class MethodParametersTest {

    void paramTestMethod(String stringParam, int intParam, ClassTest classTestParam) {}
    
}
