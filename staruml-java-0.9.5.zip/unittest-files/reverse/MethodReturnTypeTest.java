package com.mycompany.packagetest;

public class MethodReturnTypeTest {

    // int Return
    int intReturnMethod() {
        return 0;
    };

    // Object Return
    ClassTest classTestReturnMethod() {
        return null;
    }

    // Collection Return
    public Enumeration<E> enumerationReturnMethod() {
        return null;
    }
    
}
